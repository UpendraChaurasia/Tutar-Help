<script setup>
const props = defineProps({
    form: Object,
});

const handleFileUpload = (field, event) => {
    const file = event.target.files[0];
    if (file) {
        props.form[field] = file;
    }
};
</script>

<template>
    <div class="rounded-3xl bg-white p-6 shadow-sm">
        <div class="grid gap-4 md:grid-cols-2">
            <div>
                <label class="block text-sm font-medium text-slate-700">Document Type</label>
                <input type="text" v-model="props.form.document_type" class="mt-2 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500" />
                <p v-if="props.form.errors.document_type" class="mt-2 text-sm text-red-600">{{ props.form.errors.document_type }}</p>
            </div>

            <div>
                <label class="block text-sm font-medium text-slate-700">Document Number</label>
                <input type="text" v-model="props.form.document_number" class="mt-2 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500" />
                <p v-if="props.form.errors.document_number" class="mt-2 text-sm text-red-600">{{ props.form.errors.document_number }}</p>
            </div>
        </div>

        <div class="grid gap-4 md:grid-cols-2 mt-6">
            <div>
                <label class="block text-sm font-medium text-slate-700">Front Image</label>
                <input type="file" @change="(event) => handleFileUpload('front_image', event)" accept="image/*" class="mt-2 block w-full text-sm text-slate-500" />
                <p v-if="props.form.errors.front_image" class="mt-2 text-sm text-red-600">{{ props.form.errors.front_image }}</p>
            </div>
            <div>
                <label class="block text-sm font-medium text-slate-700">Back Image</label>
                <input type="file" @change="(event) => handleFileUpload('back_image', event)" accept="image/*" class="mt-2 block w-full text-sm text-slate-500" />
                <p v-if="props.form.errors.back_image" class="mt-2 text-sm text-red-600">{{ props.form.errors.back_image }}</p>
            </div>
            <div>
                <label class="block text-sm font-medium text-slate-700">Selfie Image</label>
                <input type="file" @change="(event) => handleFileUpload('selfie_image', event)" accept="image/*" class="mt-2 block w-full text-sm text-slate-500" />
                <p v-if="props.form.errors.selfie_image" class="mt-2 text-sm text-red-600">{{ props.form.errors.selfie_image }}</p>
            </div>
            <div>
                <label class="block text-sm font-medium text-slate-700">Address Proof</label>
                <input type="file" @change="(event) => handleFileUpload('address_proof', event)" accept="application/pdf,image/*" class="mt-2 block w-full text-sm text-slate-500" />
                <p v-if="props.form.errors.address_proof" class="mt-2 text-sm text-red-600">{{ props.form.errors.address_proof }}</p>
            </div>
        </div>
    </div>
</template>
