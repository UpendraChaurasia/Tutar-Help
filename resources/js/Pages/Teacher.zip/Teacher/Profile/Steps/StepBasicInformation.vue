{"explanation":"Replace basic information step with converted Vue component from provided HTML design"}
<script setup>
import { ref } from 'vue';

const props = defineProps({
        form: Object,
        profile: Object,
});

const previewPhoto = ref(props.profile?.profile_photo ? `/storage/${props.profile.profile_photo}` : null);

const handlePhotoChange = (event) => {
        const file = event.target.files[0];
        props.form.profile_photo = file;

        if (file) {
                previewPhoto.value = URL.createObjectURL(file);
        }
};
</script>

<template>
    <div class="card p-6">
        <div class="flex flex-col items-center mb-6">
            <div class="w-28 h-28 rounded-full bg-slate-100 flex items-center justify-center overflow-hidden border-2" :style="{ borderColor: '#f5a623' }">
                <img v-if="previewPhoto" :src="previewPhoto" class="w-full h-full object-cover" alt="Profile preview" />
                <span v-else class="text-3xl">👤</span>
            </div>
            <label class="mt-3 text-sm font-semibold cursor-pointer text-amber-500 flex items-center gap-2">
                <span>Upload profile photo</span>
                <input type="file" @change="handlePhotoChange" accept=".jpg,.jpeg,.png,.webp" class="hidden" />
            </label>
            <p class="hint-text mt-1">JPG, PNG or WEBP. Max 5MB.</p>
            <p v-if="props.form.errors.profile_photo" class="error-text mt-1">{{ props.form.errors.profile_photo }}</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <label class="field-label">Gender</label>
                <select v-model="props.form.gender" class="mt-1">
                    <option value="">Select gender</option>
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="other">Other</option>
                    <option value="prefer_not">Prefer not to say</option>
                </select>
                <p v-if="props.form.errors.gender" class="error-text">{{ props.form.errors.gender }}</p>
            </div>

            <div>
                <label class="field-label">Date of birth</label>
                <input type="date" v-model="props.form.date_of_birth" class="mt-1" />
                <p v-if="props.form.errors.date_of_birth" class="error-text">{{ props.form.errors.date_of_birth }}</p>
            </div>

            <div>
                <label class="field-label">Phone number</label>
                <input type="tel" v-model="props.form.phone" placeholder="+91 98765 43210" class="mt-1" />
                <p v-if="props.form.errors.phone" class="error-text">{{ props.form.errors.phone }}</p>
            </div>

            <div>
                <label class="field-label">Timezone</label>
                <select v-model="props.form.timezone" class="mt-1">
                    <option value="">Select timezone</option>
                    <option>Asia/Kolkata (IST)</option>
                    <option>America/New_York (EST)</option>
                    <option>Europe/London (GMT)</option>
                    <option>Asia/Dubai (GST)</option>
                    <option>Australia/Sydney (AEST)</option>
                </select>
                <p v-if="props.form.errors.timezone" class="error-text">{{ props.form.errors.timezone }}</p>
            </div>

            <div>
                <label class="field-label">Country</label>
                <input type="text" v-model="props.form.country" placeholder="India" class="mt-1" />
                <p v-if="props.form.errors.country" class="error-text">{{ props.form.errors.country }}</p>
            </div>

            <div>
                <label class="field-label">State</label>
                <input type="text" v-model="props.form.state" placeholder="Rajasthan" class="mt-1" />
                <p v-if="props.form.errors.state" class="error-text">{{ props.form.errors.state }}</p>
            </div>

            <div>
                <label class="field-label">City</label>
                <input type="text" v-model="props.form.city" placeholder="Jaipur" class="mt-1" />
                <p v-if="props.form.errors.city" class="error-text">{{ props.form.errors.city }}</p>
            </div>

            <div>
                <label class="field-label">Preferred language</label>
                <input type="text" v-model="props.form.preferred_language" placeholder="English" class="mt-1" />
                <p v-if="props.form.errors.preferred_language" class="error-text">{{ props.form.errors.preferred_language }}</p>
            </div>
        </div>
    </div>
</template>
