<script setup>
const props = defineProps({
    form: Object,
    profile: Object,
    canSubmit: Boolean,
});
</script>

<template>
    <div class="rounded-3xl bg-white p-6 shadow-sm">
        <div class="space-y-4">
            <div>
                <h3 class="text-lg font-semibold text-slate-900">Review & Submit</h3>
                <p class="text-sm text-slate-500">Review your entered data before final submission.</p>
            </div>

            <div class="grid gap-4 md:grid-cols-2">
                <div>
                    <p class="text-sm font-semibold text-slate-700">Full Name</p>
                    <p class="text-slate-600">{{ profile?.name || 'Not provided' }}</p>
                </div>
                <div>
                    <p class="text-sm font-semibold text-slate-700">Email</p>
                    <p class="text-slate-600">{{ profile?.email || 'Not provided' }}</p>
                </div>
                <div>
                    <p class="text-sm font-semibold text-slate-700">Headline</p>
                    <p class="text-slate-600">{{ props.form.headline || 'Not provided' }}</p>
                </div>
                <div>
                    <p class="text-sm font-semibold text-slate-700">Subjects</p>
                    <p class="text-slate-600">{{ props.form.subjects?.join(', ') || 'Not provided' }}</p>
                </div>
                <div class="md:col-span-2">
                    <p class="text-sm font-semibold text-slate-700">Short Bio</p>
                    <p class="text-slate-600">{{ props.form.short_bio || 'Not provided' }}</p>
                </div>
            </div>

            <div class="rounded-3xl border border-slate-200 bg-slate-50 p-4">
                <p class="font-semibold text-slate-700">Submit action</p>
                <p class="text-sm text-slate-500">Use the form buttons below to save as draft or submit for approval when your profile is complete.</p>
            </div>

            <div class="flex flex-wrap gap-3">
                <button type="button" class="rounded-md bg-amber-500 px-4 py-2 text-sm font-semibold text-white hover:bg-amber-600" @click="$emit('submit-approval')" :disabled="!props.canSubmit">
                    Submit for Approval
                </button>
                <p v-if="!props.canSubmit" class="self-center text-sm text-slate-500">Complete required fields to enable final submit.</p>
            </div>
        </div>
    </div>
</template>
